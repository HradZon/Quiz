package quiz;


import java.util.Collections;
import java.util.List;
import java.util.Scanner;


/**
 * Hier befindet sich die Spiellogik. Das Spiel wird initialisiert. Danach werden die Runden gestartet und eine Siegesnachricht und eine Motivationsnachricht an den Spieler übermittelt.
 */
public class Spiel {
	
	int anzahlRunden = 0;
	final List<Frage> fragen;
	private Scanner scanner;
	public Spiel(List<Frage> fragen) {
		this.fragen = fragen;
		scanner = new Scanner(System.in);
	}
	
	//In dieser Methode wird das Spiel gestartet. Zunächst wird nach der Anzahl der Spieler und deren Namen gefragt. Dann wird die Methode 'runde' aufgerufen. Zuletzt wird der Spieler gefragt, ob er eine weiter Runde spielen möchte.
	public void spielStart(){
		Spieler spieler1 = null;
        Spieler spieler2 = null;
		
        //Hier wird abgefragt, wie viele Spieler mitspielen
		System.out.print("Wie viele Spieler möchten Spielen?(1/2) ");
		int anzahlSpieler = scanner.nextInt();
		scanner.nextLine();
		
		//Falls eine ungültige Anzahl an Spielern angegeben wird, wird die Frage erneut gestellt, bis eine gültige Angabe gemacht wird.
		while(anzahlSpieler != 1 && anzahlSpieler != 2) {
			System.out.println("Fehlerhafte Eingabe. Bitte erneut die Spieleranzahl eingeben.(1/2) ");
			anzahlSpieler = scanner.nextInt();
			scanner.nextLine();
		}
		
		//Abhängig von der Anzahl der Spieler, werden die Namen abgefragt.
		if(anzahlSpieler == 1) {
			System.out.print("Wie lautet Ihr Name? ");
			spieler1 = new Spieler(scanner.nextLine());
		}else {
			System.out.print("Wie lautet der Name des ersten Spielers? ");
			spieler1 = new Spieler(scanner.nextLine());	
			System.out.print("Wie lautet der Name des zweiten Spielers? ");
			spieler2 = new Spieler(scanner.nextLine());
		}
		
		// In dieser Schleife, werden die Runden aufgerufen, solange sich die Spieler entscheiden weiterzuspielen.
		while(true) {
			if(anzahlSpieler == 1) {
				runde(spieler1);
			}else {
				runde(spieler1);
				runde(spieler2);
				sieger(spieler1, spieler2);
			}
			
			
			anzahlRunden++;
			System.out.println("Eine weitere Runde?(ja/nein) ");
			boolean weitereRunde;
			weitereRunde = scanner.nextLine().equalsIgnoreCase("ja");
			
			//Falls eine andere Anwort als 'ja' gegeben wird, wird keine weiter Runde gespielt. Der while-Schleife wird unterbrochen.
			if(weitereRunde == false) {
				break;
			}
			
			//Die Punkte der Spieler werden resetet.
			spieler1.resetPunkte();
			if(spieler2 != null) {
				spieler2.resetPunkte();
			}
		}
	}
	
	//In dieser Methode werden die einzelnen Runden ausgespielt. Der Spieler bekommt 10 zufällig ausgewählte Fragen präsentiert und muss sie beantworten.
	private void runde(Spieler spieler){
		//Dieser Befehl mischt den Fragen-Array und macht die Auswahl damit zufällig
		Collections.shuffle(fragen);
		// Dieser befehlt wählt die ersten 10 Fragen des gemischten Array aus.
		List<Frage> zufallFragen = fragen.subList(0, 10);	
		for (int i = 0; i < zufallFragen.size(); i++) {
			Frage frage = zufallFragen.get(i); 
			System.out.println("Frage " + (i+1) + "(" + spieler.getName() +"): " + frage.getFrage());
			System.out.println("a) " + frage.getAntwort1());
			System.out.println("b) " + frage.getAntwort2());
			System.out.println("c) " + frage.getAntwort3());
			System.out.println("d) " + frage.getAntwort4());
			
			String antwort = scanner.nextLine();
			//Dieser if-Abfragen klärt, ob die Antwort korrekt ist. Falls ja wird der Punktestand des Spielers um 1 erhöht. Der Spieler bekommt außerdem eine Rückmeldung.
			if (frage.isCorrect(antwort)) {
                spieler.addPunkt();
                System.out.println("Richtig!\n");
            } else {
                System.out.println("Falsch!\n");
            }
		}
		rundenAbschluss(spieler);
	}
	
	//In dieser Methode wird dem Spieler gesagt, ob er sich verbessert oder verschlechtert hat. Danach bekommt er eine Motivationsnachricht basierend auf seiner erreichten Gesamtpunktzahl.
	private void rundenAbschluss(Spieler spieler) {
		System.out.println(spieler.getName() + ", Sie haben " + spieler.getPunkte() + " Punkte geholt!");
		
		//Die Abfrage findet nur statt, wenn bereits mindestens eine Runde gespielt wurde.
		if(anzahlRunden > 0) {
			if (spieler.getPunkte() > spieler.getLetzteRunde()) {
				System.out.println("Sie haben sich verbessert! Eben hatten Sie nur " + spieler.getLetzteRunde() + " Punkte.");
			}else if (spieler.getPunkte() < spieler.getLetzteRunde()){
				System.out.println("Eben hatten Sie " + spieler.getLetzteRunde() + " Punkte. Nächste Runde wird wieder besser!");
			}
		}
		
		if(spieler.getPunkte() == 10) {
			System.out.println("Herzlichen Glückwunsch! Sie haben die volle Punktzahl erreicht!");
		}else if (spieler.getPunkte() == 9) {
			System.out.println("Das war knapp! Schaffst du nächstes Mal die volle Punktzahl?");
		}else if (spieler.getPunkte() == 8) {
			System.out.println("Klasse! Ein sehr gutes Ergebnis!");
		}else if (spieler.getPunkte() == 7) {
			System.out.println("Ein gutes Ergebnis.");
		}else if (spieler.getPunkte() == 6) {
			System.out.println("Akzeptables Ergebis. Aber da ist bestimmt noch mehr drin.");
		}else if (spieler.getPunkte() == 5) {
			System.out.println("Ein durchschnittliches Ergebnis.");
		}else if (spieler.getPunkte() == 4) {
			System.out.println("Immerhin. Vielleicht geht nächste Runde mehr.");
		}else if (spieler.getPunkte() == 3) {
			System.out.println("Da ist bestimmt mehr drin.");
		}else if (spieler.getPunkte() == 2) {
			System.out.println("Leider nicht sehr gut.");
		}else if (spieler.getPunkte() == 1) {
			System.out.println("Das lief leider nicht so gut. Vielleicht geht es nächste Runde besser.");
		}else if (spieler.getPunkte() == 0) {
			System.out.println("Leider keine Punkte. Hoffentlich klappt es nächstes Mal.");
		}
		System.out.println();
	}
	
	//In dieser Methode wird der Sieger ermittelt, wenn 2 Spieler gespielt haben. Der Sieger(oder ob es ein Unentschieden gegeben hat) wird in der Konsole angezeigt, zusammen mit der erreichten Punktzahl.
	private void sieger(Spieler spieler1, Spieler spieler2) {
		
		
		if(spieler1.getPunkte() > spieler2.getPunkte()) {
			System.out.println(spieler1.getName() + " hat mit " + spieler1.getPunkte()+ " Punkten gewonnen!");
			System.out.println(spieler2.getName() + "hat " + spieler2.getPunkte() + " Punkte geholt.");
		}else if (spieler1.getPunkte() < spieler2.getPunkte()) {
			System.out.println(spieler2.getName() + " hat mit " + spieler2.getPunkte()+ " gewonnen!");
			System.out.println(spieler1.getName() + " hat " + spieler1.getPunkte() + " Punkte geholt.");
		}else {
			System.out.println("Unentschieden! Beide Spieler haben " + spieler1.getPunkte() + " Punkte geholt.");
		}
		
	}

}
