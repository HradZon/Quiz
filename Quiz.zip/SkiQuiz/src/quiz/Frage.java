package quiz;


/**
 * In dieser Klasse werden die Fragen definiert. Sie bestehen aus der Frage selbst, 4 Antwortmöglichkeiten und der korrekten Lösung.
 */
public class Frage {
	
	private String frage;
	private String antwort1;
	private String antwort2;
	private String antwort3;
	private String antwort4;
	private String loesung;
	
	
	public Frage(String frage, String antwort1, String antwort2, String antwort3, String antwort4, String loesung) {
        this.frage = frage;
        this.antwort1 = antwort1;
        this.antwort2 = antwort2;
        this.antwort3 = antwort3;
        this.antwort4 = antwort4;
        this.loesung = loesung;
    }

	/**
	 * @return the frage
	 */
	public String getFrage() {
		return frage;
	}

	/**
	 * @return the antwort1
	 */
	public String getAntwort1() {
		return antwort1;
	}

	/**
	 * @return the antwort2
	 */
	public String getAntwort2() {
		return antwort2;
	}

	/**
	 * @return the antwort3
	 */
	public String getAntwort3() {
		return antwort3;
	}

	/**
	 * @return the antwort4
	 */
	public String getAntwort4() {
		return antwort4;
	}
	
	
	//In dieser Methode wird abgefragt, ob die gegebene Antwort mit der Lösung übereinstimmt. Falls ja wird 'true' zurpckgegeben.
	public boolean isCorrect(String antwort) {
        if(antwort.equalsIgnoreCase(loesung)) {
        	return true;
        }else {
        	return false;
        }
    }
	

}
