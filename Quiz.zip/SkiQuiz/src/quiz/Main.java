package quiz;

import java.util.ArrayList;
import java.util.List;

public class Main {
	
	
	//Die Main-Methode bildet einen Array aus Fragen. Dann wird die Klasse Spiel aufgerufen, dabei werden die Fragen übergeben. Dann wird die Methode spielStart aufgerufen.
	public static void main(String[] args) {
		
		//Im Folgenden wird ein Array gebildet und mit Fragen gefüllt.
		final List<Frage> fragen;
		
    	fragen = new ArrayList<>();
  	
    	fragen.add(new Frage("Wie hoch ist der Mont Blanc?", "3705 Meter", "5205 Meter", "4805 Meter", "4205 Meter", "c"));     
    	fragen.add(new Frage("In welchem Land befindet sich Kaprun?", "Schweiz", "Italien", "Österreich", "Deutschland", "c"));
    	fragen.add(new Frage("Welcher dieser Skiorte befindet sich in Deutschland?", "Grainau", "Fügen", "Altenmarkt", "Abtenau", "a"));
        fragen.add(new Frage("Welches dieser Skigebiete liegt am höchsten?", "Mariaalm", "Les Menuires", "Berchtesgaden", "Zell am See", "b"));  
        fragen.add(new Frage("Welches dieser Skigebiete liegt am niedrigsten?", "Lofer", "Niederau", "Lavarone", "Berchtesgaden", "d"));
        fragen.add(new Frage("In welchem Land liegt der höchste Berg der Alpen?", "Frankreich", "Schweiz", "Österreich", "Italien", "a"));
        fragen.add(new Frage("Welches ist der höchste Berg Italiens?", "Nordend", "Zumsteinspitze", "Monte Bianco di Courmayeur", "Matterhorn", "c"));
        fragen.add(new Frage("In welchem Land befindet sich das Skigebiet Brixen im Thale", "Italien", "Schweiz", "Österreich", "Deutschland", "c"));
        fragen.add(new Frage("Welcher dieser Berge liegt in Frankreich?", "Piz Bernina", "Arcalod", "Marmolata", "Monte Baldo", "b"));
        fragen.add(new Frage("Welches Skigebiet in den Alpen ist für seine berühmte Streif-Abfahrt bekannt?", "Zermatt", "St. Moritz", "Kitzbühel", "Chamonix", "c"));
        fragen.add(new Frage("Welcher dieser Skiorte befindet sich am Dachsteinmassiv?", "Söll", "Fügen", "Abtenau", "Heiligenblut", "c"));
        fragen.add(new Frage("In welchem Ort fanden die olympischen Winterspiele 2006 statt?", "München", "Zürich", "Turin", "Salzburg", "c"));
        fragen.add(new Frage("Welches ist der höchste Berg Österreichs?", "Wildspitze", "Großglockner", "Weißkugel", "Glocknerwand", "b"));
        fragen.add(new Frage("Welches ist der höchste Berg der Schweiz?", "Dufourspitze", "Dom", "Liskamm", "Matterhorn", "a"));
        fragen.add(new Frage("Welches ist das größte zusammenhängende Skigebiet Europas?", "St. Anton", "Les Trois Vallées", "Zermatt", "Ischgl", "b"));
        fragen.add(new Frage("Welches ist das größte Skigebiet außerhalb Europas?", "Aspen", "Whistler Blackcomb", "Park City", "Vail", "b"));
        fragen.add(new Frage("Welcher dieser Berge liegt in Österreich?", "Hoher Dachstein", "Piz Bernina", "Ortler", "Säntis", "a"));
        fragen.add(new Frage("Welcher dieser Berge liegt in Italien?", "Dufourspitze", "Monte Baldo", "Birnhorn", "Piz Bernina", "b"));
        fragen.add(new Frage("Welches dieser Skigebiete ist am größten?", "Heiligenblut", "Livigno", "Tignes", "Berchtesgaden", "c"));
        fragen.add(new Frage("In welchem Land werden die olympischen Winterspiele 2026 stattfinden?", "Deutschland", "Frankreich", "Italien", "Schweiz", "c"));

		//Nun wird ein Spiel initialisert und dann gestartet. Dabei wird das Array mit den Fragen übergeben.
		Spiel spiel = new Spiel(fragen);
		spiel.spielStart();
		
	}

}
