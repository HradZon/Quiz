package quiz;

/**
 * In dieser Klasse wird der Spieler definiert. Er hat einen Namen, einen Punktestand und den Punktestand der vergangenen Runde.
 */
class Spieler {
	private String name;
	private int punkte;
	private int letzteRunde;

	public Spieler(String name) {
		this.name = name;	
		this.punkte = 0;
	    this.letzteRunde = 0;
	}

	
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return the punkte
	 */
	public int getPunkte() {
		return punkte;
	}

	/**
	 * @return the letzteRunde
	 */
	public int getLetzteRunde() {
		return letzteRunde;
	}
	
	//Diese Methode wird aufgerufen, wenn ein Spieler eine Frage richtig beantwortet hat. Sein Punktestand wird um 1 erhöht.
	public void addPunkt() {
	    this.punkte++;
	}
	
	//Nach einer Runde, wird der Punktestand des Spielers zurückgesetzt. Zuvor wird sein Punktestand in der Variable 'letzteRunde' gespeichert.
	public void resetPunkte() {
	    this.letzteRunde = this.punkte;
	    this.punkte = 0;
	}

	
}	
